﻿using System;
namespace SampleExcel.Component.Base
{
    public interface IExcelGroupProperty : IExcelPropertiesContainer
    {
    }
}
