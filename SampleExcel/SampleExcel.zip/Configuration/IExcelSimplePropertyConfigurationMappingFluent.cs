﻿using System;
namespace SampleExcel.Configuration
{
    public interface IExcelSimplePropertyConfigurationMappingFluent<TDto> : IExcelPropertyConfigurationMappingFluent { }
}
